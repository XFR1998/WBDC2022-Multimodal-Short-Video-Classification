from tfrecord.tools import tfrecord2idx

from tfrecord.tools.tfrecord2idx import create_index
